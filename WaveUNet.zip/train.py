import os
import torch
import numpy as np
from tqdm import tqdm
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.utils.data import DataLoader
from models.wave_net import WaveUNet
from dataset.audioDataset import AudioDataset

MODEL_PATH = 'result/model.pth'
MODEL_MIN_PATH = 'result/model_min.pth'
TRAIN_PATH = 'musdb18wav/train_down/'
TEST_PATH = 'musdb18wav/test_down/'
train_list = []
test_list = []
for root, dirs, files in os.walk(TRAIN_PATH):
    for dir in dirs:
        train_list.append(dir)

for root, dirs, files in os.walk(TEST_PATH):
    for dir in dirs:
        test_list.append(dir)


def main():
    lr = 1e-3
    batch_size = 8
    sample_size = 16384
    epochs = 50
    train_dataset = AudioDataset(train_list, TRAIN_PATH)
    test_dataset = AudioDataset(test_list, TEST_PATH)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    model = WaveUNet()
    model = model.cuda()

    optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999))
    step_lr = lr_scheduler.MultiStepLR(optimizer, [20, 40], 0.1)
    criterion = nn.MSELoss()

    min_loss = float('inf')
    for epoch in tqdm(range(1, epochs + 1)):
        model.train()
        epoch_loss = 0.0

        for i, (mixture, vocals) in enumerate(train_loader):
            idx = np.arange(0, mixture.size()[-1], sample_size)
            for j, ind in enumerate(idx):
                data = mixture[:, 0, ind: ind + sample_size].unsqueeze(1).cuda()
                target = vocals[:, 0, ind: ind + sample_size].unsqueeze(1).cuda()
                outputs = model(data)
                loss = criterion(outputs, target)
                epoch_loss = +loss.data
                loss.backward()
                optimizer.step()
                if j % 10 == 0:
                    s = 'Train epoch: {} [{:4d}/{:4d} Total Dataset: {:4d}] loss: {:.6f}'.format(
                        epoch, i, len(idx), len(train_loader), loss.data)
                    print(s)
        step_lr.step()

        model.eval()
        valid_loss = 0.0
        with torch.no_grad():
            for i, (mixture, vocals) in enumerate(test_loader):
                data = mixture[0, 0, 0:sample_size]
                target = vocals[0, 0, 0:sample_size]
                outputs = model(data)
                loss = criterion(outputs, target)
                valid_loss = +loss.data
            if valid_loss < min_loss:
                print('Min valid loss is: {.6f} with {}'.format(valid_loss, epoch))
                min_loss = valid_loss
                torch.save(model.state_dict(), MODEL_MIN_PATH)

    torch.save(model.state_dict(), MODEL_PATH)


if __name__ == '__main__':
    main()


