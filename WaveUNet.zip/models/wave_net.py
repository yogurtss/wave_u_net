import torch
import torch.nn as nn
import torch.nn.functional as F


class convolution(nn.Module):
    def __init__(self, in_chs, out_chs, kernel_size, stride=1, with_bn=True):
        super(convolution, self).__init__()

        pad = (kernel_size - 1) // 2
        self.conv = nn.Conv1d(in_chs, out_chs, kernel_size, stride, pad)
        self.bn = nn.BatchNorm1d(out_chs) if with_bn else nn.Sequential()
        self.relu = nn.LeakyReLU(inplace=True)
        # self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class dilated_convolution(nn.Module):
    def __init__(self, in_chs, out_chs, kernel_size, stride=1, dilation=2, with_bn=True):
        super(dilated_convolution, self).__init__()
        pad = dilation * (kernel_size - 1) // 2
        self.conv = nn.Conv1d(in_chs, out_chs, kernel_size, stride, pad, dilation)
        self.bn = nn.BatchNorm1d(out_chs) if with_bn else nn.Sequential
        self.relu = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class DownBlock(nn.Module):
    def __init__(self, in_chs, out_chs, k, dilation=1):
        super(DownBlock, self).__init__()
        if dilation == 1:
            self.conv = convolution(in_chs, out_chs, kernel_size=k)
        else:
            self.conv = dilated_convolution(in_chs, out_chs, kernel_size=k, dilation=dilation)

    def forward(self, x, merge_x):
        x = self.conv(x)
        merge_x.append(x)
        return F.interpolate(x, scale_factor=0.5)


class UpBlock(nn.Module):
    def __init__(self, in_short, in_chs, out_chs, k):
        super(UpBlock, self).__init__()
        self.conv = convolution(in_chs + in_short, out_chs, kernel_size=k)

    def forward(self, shortcut, x):
        x = F.interpolate(x, scale_factor=2)
        x = torch.cat([shortcut, x], dim=1)
        x = self.conv(x)
        return x


class WaveUNet(nn.Module):
    '''
    Impletation of waveUnet
    layers: number of convolutional layer, default=12
    ch_in: number of input audio chaneel, default=1, means we use one microphone to measure results
    ch_out: number of output audio channel, default=1
    fd: kernel size of the DownsampleBlock, default=15
    fu: kernel size of the UpsampleBlock, default=5
    '''

    def __init__(self, layers=12, ch_in=1, ch_out=1, fd=15, fu=5, num_chs=24, dilation=1):

        super(WaveUNet, self).__init__()
        self.layers = layers
        in_chs = [num_chs * i for i in range(layers + 1)]
        in_chs[0] = ch_in
        out_chs = in_chs[::-1]
        out_chs.insert(0, (in_chs[-1] + num_chs))
        for i in range(layers):
            setattr(self, 'down_{}'.format(str(i)), DownBlock(in_chs[i], in_chs[i + 1], fd, dilation))

        self.center = convolution(in_chs[-1], in_chs[-1] + num_chs, fd)
        for i in range(layers):
            setattr(self, 'up_{}'.format(str(i)), UpBlock(in_chs[-1-i], out_chs[i], out_chs[i + 1], fu))
        self.out = nn.Sequential(nn.Conv1d(in_chs[1] + ch_in, ch_out, 1),
                                  nn.Tanh())

    def forward(self, x):
        raw = x
        merge_x = []
        for i in range(self.layers):
            down_layers = getattr(self, 'down_{}'.format(str(i)))
            x = down_layers(x, merge_x)
        x = self.center(x)

        for i in range(self.layers):
            up_layers = getattr(self, 'up_{}'.format(str(i)))
            x = up_layers(merge_x[-1 - i], x)
        output = self.out(torch.cat([raw, x], dim=1))
        return output


if __name__ == '__main__':
    '''
    a = torch.tensor([1.0, 3, 2, 4, 5, 6])
    a = a.unsqueeze(0).unsqueeze(1)
    b = F.interpolate(a, scale_factor=0.5)
    print(a)
    print(b)
    '''

    model = WaveUNet()
    print(model)
    a = torch.zeros([1, 1, 16384])
    b = model(a)
    print(model)
